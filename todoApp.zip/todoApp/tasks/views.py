from django.shortcuts import render, redirect
from .models import Task
from .forms import TaskForm
import requests

def index(request):
    tasks = Task.objects.all()

    # Fetch a random quote
    response = requests.get('https://api.quotable.io/random')
    if response.status_code == 200:
        quote = response.json().get('content')
    else:
        quote = "An error occurred while fetching the quote."

    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = TaskForm()

    context = {'tasks': tasks, 'form': form, 'quote': quote}
    return render(request, 'tasks/index.html', context)

def update_task(request, task_id):
    task = Task.objects.get(id=task_id)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = TaskForm(instance=task)

    context = {'form': form}
    return render(request, 'tasks/update_task.html', context)

def delete_task(request, task_id):
    task = Task.objects.get(id=task_id)
    if request.method == 'POST':
        task.delete()
        return redirect('index')

    context = {'task': task}
    return render(request, 'tasks/delete_task.html', context)

def complete_task(request, task_id):
    task = Task.objects.get(id=task_id)
    if request.method == 'POST':
        task.completed = not task.completed
        task.save()
    return redirect('index')
